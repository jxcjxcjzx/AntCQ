describe('beta', function(){
  it('should be executed second', function(){
    global.beta = 1;
  });
});
