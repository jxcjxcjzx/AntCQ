var test = require('../../../');
test(function (t) {
    t.plan(1);
    t.equal('beep', 'boop');
});
