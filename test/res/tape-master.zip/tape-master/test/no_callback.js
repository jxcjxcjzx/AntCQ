var test = require('../');

test('No callback.');
