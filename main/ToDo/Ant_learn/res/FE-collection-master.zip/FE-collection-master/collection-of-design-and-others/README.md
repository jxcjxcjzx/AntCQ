# 前端收集-设计和其他

- 设计
    - 导航
        - [腾讯-设计导航](http://idesign.qq.com/)
    - 网页设计相关的一些聚合类网站:
        - [FWA - Favourite Website Awards](http://www.thefwa.com/)
        - [Awwwards - Website Awards - Best Web Design Trends](http://www.awwwards.com/)
        - [Reeoo | web design inspiration and website gallery](http://reeoo.com/)
        - [One Page Love](https://onepagelove.com/)
        - [CSS Winner - Website Awards - CSS Award Gallery for Web Design Inspiration](http://www.csswinner.com/)
        - [CSS Design Awards - Website Awards &amp; Inspiration - CSS Gallery - CSSDA](http://www.cssdesignawards.com/)
- 产品经理: [纯银](http://weibo.com/cicada) / [lumiwu(前微信交互)](http://lumiwu.com/)
- 设计师: [Kevin Zhow(<Productor>作者)](http://blog.zhowkev.in/) / [亭决-Thu](http://www.infoier.com/) / [BeForWeb(ISUX交互大牛)](http://beforweb.com/) / 
- 数据分析: [纪杨(Google Analytics/Piwik)](http://jiyang.me/)
- 数据可视化: [manovich](http://manovich.net/)
- 安全: [云舒(阿里安全专家)](http://www.icylife.net/) / [吴翰清/道哥的黑板报(前阿里安全)](http://www1.taosay.net/)
- Freelance: [freelancer.com](https://www.freelancer.com) / [elance.com](https://www.elance.com/) / [猪八戒网](http://www.zhubajie.com/)

