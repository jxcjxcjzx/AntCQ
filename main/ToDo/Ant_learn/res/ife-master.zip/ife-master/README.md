![百度Web前端技术学院](asset/github.jpg)

# 学院介绍

## 这是一个什么样的学院

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;**百度Web前端技术学院**（Baidu Institute of Front-End Technology简称IFE）是一个由百度人力资源部校园招聘组、百度EFE团队联合出品的、面向在校大学生以及对前端技术有兴趣的前端在线学习平台，我们希望能够借助百度大量优秀的前端工程师以及丰富的前端知识积累，帮助人们更加有趣、高效、系统地学习Web前端技术。

* [2015 暑期训练营](https://github.com/baidu-ife/ife/tree/master/2015_summer)
* [2015 春季班](https://github.com/baidu-ife/ife/tree/master/2015_spring)

# 联系我们

欢迎在项目的<a href="https://github.com/baidu-ife/ife/issues" target="_blank">issue</a>中提问，我们会在那里进行回答。

如果有不方便公开讨论的问题，可以通过邮件 ife(at)baidu.com 联系我们。

更加欢迎关注我们的<a href="http://weibo.com/baiduife" target="_blank">微博 weibo.com/baiduife</a>

关注我们的微信公众号：搜索baidu_ife或扫描下方二维码
![二维码](asset/weixin.jpeg)
