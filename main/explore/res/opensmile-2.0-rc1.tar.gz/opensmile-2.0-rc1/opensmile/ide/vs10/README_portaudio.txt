unpack portaudio to 
trunk/../thirdparty/portaudio

copy portaudio.* from this dir to 
trunk/../thirdparty/portaudio/build/msvc
(overwrite = yes)