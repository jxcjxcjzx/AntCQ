works for openCV 2.4.5 (lib file names include the version number!!!)

the openCV include files must be contained in:
trunk/../thirdparty/compiled/include

the openCV lib files must be contained in:
trunk/../thirdparty/compiled/lib


Note:
for other openCV versions the opencv.props file should be changed!

